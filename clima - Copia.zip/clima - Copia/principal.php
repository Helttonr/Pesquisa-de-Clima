<?php
require_once('Connections/connection.php');

$PDO = db_connect();
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];
$visible = '';
if ($perfil == 'cliente') {
	$visible = 'disabled';
}

require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');




?>


<?php if ($perfil == 'Administrador') {  	?>

	<div class="container-fluid">
		<div class="row">

			<div class="col-3 text-center">
				<button class="btn btn-primary" onClick="location.href ='clima_list.php'"><i class="fa fa-tripadvisor fa-3x" aria-hidden="true"></i></button>
				<p><small class="text-muted"><strong> Clima Organizacional</strong></small></p>
			</div>	
			<div class="col-3 text-center">
				<button class="btn btn-primary" onClick="location.href ='index.php'"><i class="fa fa-power-off fa-3x" aria-hidden="true"></i></button>
				<p><small class="text-muted"><strong> Sair</strong></small></p>
			</div>

		</div>
	<?php } ?>
	


<?php require_once('./inc/footer.inc.php'); ?>