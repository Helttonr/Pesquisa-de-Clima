﻿<?php    
require_once('Connections/connections.php');
    $PDO = db_connect();

    session_start();
    $matricula = $_SESSION['smatricula'];
    $perfil = $_SESSION['sperfil'];
    $nome = $_SESSION['snome'];
    $unidade = $_SESSION['sunidade'];
    require_once('./inc/header.inc.php');

  // Enviar os dados da tela para Banco de dados
  $Matricula= isset($_POST["Matricula"]) ? $_POST["Matricula"] : null;
  $Nome = isset($_POST["Nome"]) ? $_POST["Nome"] : null;
  $Setor = isset($_POST["Setor"]) ? $_POST["Setor"] : null;
  $Turno = isset($_POST["Turno"]) ? $_POST["Turno"] : null;
  $Email = isset($_POST["Email"]) ? $_POST["Email"] : null;
  $Senha = isset($_POST["Senha"]) ? $_POST["Senha"] : null;
  $Perfil = isset($_POST["Perfil"]) ? $_POST["Perfil"] : null;
  $Unidade = isset($_POST["Unidade"]) ? $_POST["Unidade"] : null;
  $Ativo = isset($_POST["Ativo"]) ? $_POST["Ativo"] : null;

  $action = isset($_POST["action"]) ? $_POST["action"] : null;

  if ($action == "insert") {


// Validar se Existe MatriculaSese na tabela  
$sql_entrada  = "SELECT Matricula FROM usuario where Matricula = :Matricula";
$stmt_entrada = $PDO->prepare($sql_entrada);
$stmt_entrada->bindParam(':Matricula', $Matricula);
$result = $stmt_entrada->execute();
$result =   $stmt_entrada->fetch(PDO::FETCH_ASSOC);
if ($result >= 1) {
  $_SESSION['funcionario'] = "";
  header("Location: c_usuario.php");
    exit;

}  else {

    $sql_entrada = "INSERT INTO usuario (Matricula,  Nome, Setor, Turno, Email, Senha, Perfil, Unidade) 
  VALUES (:Matricula, :Nome, :Setor,:Turno ,:Email, :Senha, :Perfil, :Unidade)";

    $stmt_entrada = $PDO->prepare($sql_entrada);
    $stmt_entrada->bindParam(':Matricula', $Matricula);
    $stmt_entrada->bindParam(':Nome', $Nome);
    $stmt_entrada->bindParam(':Setor', $Setor);
    $stmt_entrada->bindParam(':Turno', $Turno);
    $stmt_entrada->bindParam(':Email', $Email);
    $stmt_entrada->bindParam(':Senha', $Senha);
    $stmt_entrada->bindParam(':Perfil', $Perfil);
    $stmt_entrada->bindParam(':Unidade', $Unidade); 
    $result = $stmt_entrada->execute();    
    if ($result)    {
      $_SESSION['salvo'] = "Salvo com Sucesso";
      header("Location: c_usuario.php");
   exit;
  } 

}
    


} if  ($action == "update") {

    $sql_entrada = "UPDATE usuario SET Matricula=:Matricula ,Nome=:Nome, 
    Setor=:Setor, Turno=:Turno, Email=:Email, Senha=:Senha, 
    Perfil=:Perfil,Unidade=:Unidade, Ativo=:Ativo WHERE Matricula=:Matricula";
    
    $stmt_entrada = $PDO->prepare($sql_entrada);
    $stmt_entrada->bindParam(':Matricula',$Matricula);
    $stmt_entrada->bindParam(':Nome', $Nome);
    $stmt_entrada->bindParam(':Setor', $Setor);
    $stmt_entrada->bindParam(':Turno', $Turno);
    $stmt_entrada->bindParam(':Email', $Email);
    $stmt_entrada->bindParam(':Senha', $Senha);
    $stmt_entrada->bindParam(':Perfil', $Perfil);
    $stmt_entrada->bindParam(':Unidade', $Unidade);
    $stmt_entrada->bindParam(':Ativo', $Ativo);
    $result = $stmt_entrada->execute();
    if ($result) {
      $_SESSION['editado'] = "Editado  Com Sucesso!";
      header("Location: c_usuario.php");
      exit(0);
    } else {
      $_SESSION['editado'] = "Erro  Não foi possivel Edição!";
      header("Location: c_usuario.php");
      exit(0);
    }
  
  }
  
