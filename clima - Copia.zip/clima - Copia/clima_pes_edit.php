<?php
require_once('Connections/connection.php');
$PDO = db_connect();

session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];



require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');

$idretorna = $_GET['ID'];
$sql = "SELECT dc.ID,dc.Descricao as Descricao,dc.Ativo, tc.Nome AS NomeTipoClima 
FROM descricao_clima dc INNER JOIN tipo_clima tc ON dc.tipo_clima_ID = tc.ID WHERE dc.ID=$idretorna and dc.Ativo = 'SIM' ";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':ID', $idretorna, PDO::PARAM_INT);
$stmt->execute();
$edit = $stmt->fetch(PDO::FETCH_ASSOC);


$sql_parada = "SELECT  * FROM c_ativo";
$stmt = $PDO->prepare($sql_parada);
$stmt->execute();
$ativo = $stmt->fetchAll(PDO::FETCH_ASSOC);




?>
<div class="container-fluid">
    <h3 class="panel-title">
        <h3 class="m-0 font-weight-bold text-danger">
            <i class="fa fa-pencil" aria-hidden="true"></i> Edição - <?php echo $edit['NomeTipoClima']; ?>
        </h3>
    </h3>
    <hr>
    <form name="form1" class="row g-3" method="post" action="clima_pes_save.php">
        <!-- MSG de Alert -->
        <?php include('message/message.php'); ?>
        <div style="display: none;">
            <label>ID</label>
            <input type="text" class="form-control" id="ID" name="ID" value="<?php echo $edit['ID']; ?>">
        </div>
        <div class="col-sm-11">
            <label class="form-label"><b>Descrição:</b></label>
            <input type="text" class="form-control" id="Descricao" name="Descricao" value="<?php echo $edit['Descricao']; ?>">
        </div>
        <div class="col-sm-1 form-group">
            <label class="form-label"><b>Ativo:</b></label>
            <select class="form-control" name="Ativo" id="Ativo">
                <option><?php echo $edit['Ativo']; ?></option>
                <?php foreach ($ativo as $row) {
                    echo "<option >$row[Nome] </option>";
                }   ?>
            </select>
        </div>
</div>
<div class="col-md-12">
    <!-- Botão de Gravar -->
    <div class="footer d-flex justify-content-between mb-3">
        <button type="submit" class="btn btn-primary me-2" name="action" id="action" value="update">
            <i class="fa-sharp fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar
        </button>
    </div>
</div>
</div>
</form>
</div>


<?php require_once('./inc/footer.inc.php'); ?>