<?php
session_start();

require_once('Connections/connection.php');
$PDO = db_connect();

$perfil = $_SESSION['sperfil'];
require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');

$sql = "SELECT * FROM tipo_clima WHERE Ativo = 'SIM'";
$stmt = $PDO->prepare($sql);
$stmt->execute();
$Cod = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>

<div class="container-fluid">
    <h3 class="panel-title"><img src="./img/dashboard/clima.png" width="100" height="70" alt="">Guia para pesquisa de clima</h3>
    <hr> 
    <div class="container-fluid mt-2">
        <form id="form1" name="form1" class="form-horizontal" method="get" action="clima_list.php" onsubmit="return validateForm()">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <select class="form-control" title="Selecione Organizacional" data-live-search="true" name="ID" id="ID">
                            <option value="">Selecione</option>                        
                            <?php foreach ($Cod as $row) : ?>                               
                                <option style="font-size: 40px;" value="<?= ($row['ID']) ?>">
                                    <?= ($row['Nome']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>    
      
            <div class="row">
                <div class="col-md-12">
                    <!-- Botão de submissão -->
                    <button style="font-size: 30px;" type="submit" class="btn btn-primary">Pesquisar</button>
                </div>
            </div>
        </form>
        
      
    </div>
</div>

<?php require_once('./inc/footer.inc.php'); ?>

<script>
    function validateForm() {
        var selectedValue = document.getElementById("ID").value;
        if (selectedValue === "") {
            alert("Por favor, selecione uma opção.");
            return false; // Impede o envio do formulário se o campo não estiver selecionado
        }
        return true; // Permite o envio do formulário se a validação passar
    }
</script>
