<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();


// Verificar se foi passado o ID do registro para visualizar/editar
if (!isset($_GET['ID'])) {
    echo "ID do registro não foi fornecido.";
    exit();
}

$idRegistro = $_GET['ID'];

// Consulta para recuperar os dados do registro pelo ID
$sqlConsulta = "SELECT * FROM dados_formulario WHERE ID = $idRegistro";
$stmtConsulta = $PDO->prepare($sqlConsulta);
$stmtConsulta->execute();
$dadosFormulario = $stmtConsulta->fetch(PDO::FETCH_ASSOC);

// Verificar se encontrou o registro
if (!$dadosFormulario) {
    echo "Registro não encontrado.";
    exit();
}

// Consulta para recuperar as descrições do formulário
$sql = "SELECT * FROM `dados_item` di INNER JOIN descricao_clima dc on di.ID_descricao = dc.ID where di.formulario_id = $idRegistro";
$stmt = $PDO->prepare($sql);
$stmt->execute();
$descricoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>




<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SISSBR</title>
    <link rel="stylesheet" type="text/css" href="css/app.css">
    <link rel="icon" href="./img/assets/ico/512x512-1-32x32.png" sizes="192x192" />
    <link rel="stylesheet" type="text/css" href="vendor/fontawesome/css/fontawesome.css" />
    <link href="vendor/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="vendor/fontawesome/css/solid.css" />
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="vendor/popper.min.js.map">
    <link href="vendor/DataTables-1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="vendor/DataTables-1.10.16/css/buttons.dataTables.min.css" rel="stylesheet" />
    <link href="vendor/DataTables-1.10.16/css/responsive.dataTables.min.css" rel="stylesheet" />
    <link href="vendor/jquery-ui/themes/base/jquery-ui.min.css" rel="stylesheet" />


</head>
<div class="container-fluid">
    <h5 class="panel-title"><img src="./img/dashboard/clima.png" width="100" height="70" alt="">Dados do Formulário</h5>
    <hr>
    <form class="form-horizontal">

        <table class="table table-bordered table-hover rounded responsive" style="width:100%">
            <thead>
                <tr>
                    <th>Unidade</th>
                    <th>Qual seu departamento</th>
                    <th>Trabalho na Sesé há quanto tempo</th>
                    <th>Informe o nome do gestor responsável por sua operação</th>
                    <th>Qual o nome do seu gestor direto</th>
                    <th>Comentário</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= $dadosFormulario['Unidade'] ?></td>
                    <td><?= $dadosFormulario['NomeDepartamento'] ?></td>
                    <td><?= $dadosFormulario['TempoSese'] ?></td>
                    <td><?= $dadosFormulario['ResponsavelOperacao'] ?></td>
                    <td><?= $dadosFormulario['GestorDireto'] ?></td>
                    <td><?= $dadosFormulario['Obs'] ?></td>
                </tr>
            </tbody>
        </table>

        <div class="table-responsive">
            <table class="table table-bordered table-hover rounded">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Descrição</th>
                        <th>Concordo Plenamente</th>
                        <th>Concordo</th>
                        <th>Discordo</th>
                        <th>Discordo Plenamente</th>
                        <th>N/A</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($descricoes as $index => $row) { ?>
                        <tr>
                            <td align="center">
                                <?php
                                $icon = '';
                                switch ($row['avaliacao']) {
                                    case 1:
                                        $icon = '😄';
                                        break;
                                    case 2:
                                        $icon = '😃';
                                        break;
                                    case 3:
                                        $icon = '😡';
                                        break;
                                    case 4:
                                        $icon = '🤬';
                                        break;
                                    case 5:
                                        $icon = '😐';
                                        break;
                                    default:
                                        $icon = '';
                                        break;
                                }
                                echo $icon;
                                ?>
                            </td>
                            <td align="center"><?php echo $row['Descricao']; ?></td>
                            <td align="center"><?php echo $row['avaliacao'] == 1 ? '✔' : ''; ?></td>
                            <td align="center"><?php echo $row['avaliacao'] == 2 ? '✔' : ''; ?></td>
                            <td align="center"><?php echo $row['avaliacao'] == 3 ? '✔' : ''; ?></td>
                            <td align="center"><?php echo $row['avaliacao'] == 4 ? '✔' : ''; ?></td>
                            <td align="center"><?php echo $row['avaliacao'] == 5 ? '✔' : ''; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
    </form>

    <?php require_once('./inc/footer.inc.php'); ?>