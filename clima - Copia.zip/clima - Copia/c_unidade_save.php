<?php
require_once('Connections/connections.php');
$PDO = db_connect();

session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];



   // Enviar os dados da tela para Banco de dados
   $id = isset($_POST["ID"]) ? $_POST["ID"] : null;
   $nome = isset ($_POST["Nome"]) ? $_POST["Nome"] : null;
   $action = isset($_POST["action"]) ? $_POST["action"] : null;


   if ($action == "insert"){

   $sql_entrada = "INSERT INTO c_unidade(Nome) VALUES (:Nome)";         

   $stmt_entrada = $PDO->prepare($sql_entrada);
   $stmt_entrada->bindParam(':Nome', $nome);   
   $result = $stmt_entrada->execute();
        if ($result) {
            $_SESSION['salvo'] = "Salvo  Com Sucesso!";
            header("Location: c_unidade.php");
            exit;
        } else {
            $_SESSION['salvo'] = "Erro  Não foi possivel Salvar!";
            header("Location: c_unidade.php");
            exit;
        }
   
}
elseif ($action == "update"){
   $sql_entrada = "UPDATE c_unidade SET Nome=:Nome WHERE ID=:ID";         

   $stmt_entrada = $PDO->prepare($sql_entrada);
     $stmt_entrada->bindParam(':ID', $id  );
     $stmt_entrada->bindParam(':Nome', $nome);
     $result = $stmt_entrada->execute();
     if ($result) {
         $_SESSION['editado'] = "Editado Com Sucesso!";
         header("Location:c_unidade.php");
         exit;
     } else {
         $_SESSION['editado'] = "Erro  Não foi possivel Salvar!";
         header("Location: c_unidade.php");
         exit;
     }
 }