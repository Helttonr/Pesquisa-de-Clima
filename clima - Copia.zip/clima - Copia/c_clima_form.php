<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();

require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');

$sql = "SELECT *  FROM dados_formulario WHERE Ativo = 'SIM'";
$stmt = $PDO->prepare($sql);
$stmt->execute();
$form = $stmt->fetchAll(PDO::FETCH_ASSOC);



?>

<div class="container-fluid">
    <h3 class="panel-title"><img src="./img/dashboard/clima.png" width="100" height="70" alt="">Formulários</h3>
    <hr>
    <!-- MSG de Alert -->
    <?php include('message/message.php'); ?>

    <table class="table table-bordered table-hover rounded responsive" style="width:100%">
        <thead class="table">
            <tr>
                <th>Formulário</th>
                <th>Departamento</th>
                <th>Tempo Sese</th>
                <th>Responsavel Operacao</th>
                <th>Gestor Direto</th>
                <th>Data</th>
                <th>View</th>

            </tr>
        </thead>
        <tbody>
            <?php foreach ($form as $row) : ?>
                <tr>
                    <td><?php echo $row['ID']; ?></td>
                    <td><?php echo $row['NomeDepartamento']; ?></td>
                    <td><?php echo $row['TempoSese']; ?></td>
                    <td><?php echo $row['ResponsavelOperacao']; ?></td>
                    <td><?php echo $row['GestorDireto']; ?></td>
                    <td><?php echo $row['DataHora']; ?></td>
                    <td><a href='c_clima_view.php?ID=<?= $row['ID'] ?>'>
                    <center><i style="font-size:40px;" class="fa fa-newspaper-o" title="Visualizar Formulário" aria-hidden="true"></i></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php require_once('./inc/footer.inc.php'); ?>