﻿<?php 

require_once('Connections/connection.php'); 
session_start();

$PDO = db_connect();
$matricula = isset($_POST['matricula']) ? $_POST['matricula'] : null;
$senha =isset($_POST["password"]) ? $_POST["password"] : null; 

$alertlogin = 'none';

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
	
	$sql_user = "SELECT Matricula,Nome, Unidade, Turno,Perfil,  Senha, Email FROM usuario WHERE (Matricula = :matricula OR Email = :matricula) AND senha =:senha ";
		$stmt_user = $PDO->prepare($sql_user);
		$stmt_user->bindParam(':matricula', $matricula);
		$stmt_user->bindParam(':senha', $senha);		
		$stmt_user->execute();
		$result = $stmt_user->fetch(PDO::FETCH_ASSOC);
	if (is_array($result))
	{		
		session_start();
		$_SESSION['smatricula']= $matricula; 
		$_SESSION['snome']=$result['Nome'];
		$_SESSION['sperfil']=$result['Perfil'];
		$_SESSION['sunidade']=$result['Unidade'];
		$_SESSION['sturno']=$result['Turno'];
		header("Location: principal.php"); 
     
	} else {
        $_SESSION['validacao_usuario'] = "";
        header("Location: index.php");
        exit(0);
    }
}
require_once('./inc/header.inc.php');

?>

<main class="form-signin">

    <body class="sb-nav-fixed">
        <style>
            #layoutSidenav {

                background-color: lightgray !important;
            }
        </style>
        <div id="">
            <div id="">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header bg-primary">
                                        <h3 class="text-center  font-weight-light my-4"><img src="./img/logo.png" width="150" class="img-fluid rounded-top" alt=""></h3>
                                    </div>
                                    <div class="card-body">
                                        <form method="post" action="">
                                            <!-- MSG de Alert -->
                                            <?php include('message/message.php'); ?>


                                            <div class="form-floating">
                                                <input type="Text" class="form-control" id="matricula" name="matricula" autofocus>
                                                <label for="floatingInput">Matricula ou Email:</label>
                                            </div>

                                            <br>
                                            <div class="form-floating">
                                                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                                <label for="floatingPassword">Senha:</label>
                                            </div>

                                            <br>
                                            <button type="submit" class="w-100 btn btn-lg btn-primary" value="Login" name="submit">Enter</button>


                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </main>


    </body>

</html>