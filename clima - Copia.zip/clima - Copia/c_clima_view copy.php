<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();

require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');

// Verificar se foi passado o ID do registro para visualizar/editar
if (!isset($_GET['ID'])) {
    echo "ID do registro não foi fornecido.";
    exit();
}

$idRegistro = $_GET['ID'];

// Consulta para recuperar os dados do registro pelo ID
$sqlConsulta = "SELECT * FROM dados_formulario WHERE ID = $idRegistro";
$stmtConsulta = $PDO->prepare($sqlConsulta);
$stmtConsulta->bindParam(':ID', $idRegistro, PDO::PARAM_INT);
$stmtConsulta->execute();
$dadosFormulario = $stmtConsulta->fetch(PDO::FETCH_ASSOC);

// Verificar se encontrou o registro
if (!$dadosFormulario) {
    echo "Registro não encontrado.";
    exit();
}

// Consulta para recuperar as descrições do formulário
$sql = "SELECT dc.Descricao,di.avaliacao FROM descricao_clima dc INNER JOIN tipo_clima tc on dc.tipo_clima_ID = tc.ID INNER JOIN dados_item di on dc.tipo_clima_ID = di.tipo_clima_ID WHERE dc.tipo_clima_ID = 1 GROUP BY dc.Descricao,di.avaliacao";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':idRegistro', $idRegistro, PDO::PARAM_INT);
$stmt->execute();
$descricoes = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>

<div class="container-fluid">
    <h3 class="panel-title">Dados do Formulário</h3>
    <hr>
    <form id="formVisualizacao" name="formVisualizacao" class="form-horizontal">

        <table class="table table-bordered table-hover rounded responsive" style="width:100%">
            <thead class="table">
                <tr>
                    <td align="center" bgcolor="Silver"><b>Planta</b></td>
                    <td align="center" bgcolor="Silver"><b>Qual seu departamento</b></td>
                    <td align="center" bgcolor="Silver"><b>Trabalho na Sesé há quanto tempo</b></td>
                    <td align="center" bgcolor="Silver"><b>Informe o nome do gestor responsável por sua operação</b></td>
                    <td align="center" bgcolor="Silver"><b>Qual o nome do seu gestor direto</b></td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= $dadosFormulario['Unidade'] ?></td>
                    <td><?= ($dadosFormulario['NomeDepartamento']) ?></td>
                    <td><?= ($dadosFormulario['TempoSese']) ?></td>
                    <td><?= ($dadosFormulario['ResponsavelOperacao']) ?></td>
                    <td><?= ($dadosFormulario['GestorDireto']) ?></td>

                </tr>
            </tbody>
        </table>
        <table class="table table-bordered table-hover rounded responsive" style="width:100%">
            <thead class="table">
                <tr>
                    <th>Comentário</th>
                </tr>
            </thead>
            <tbody>
                <td><?= ($dadosFormulario['Obs']) ?></td>
            </tbody>
        </table>
        <table class="table table-bordered table-hover rounded responsive" style="width:100%">
            <thead class="table">
                <tr>
                    <th>Status</th>
                    <th>Descrição</th>
                    <th>Concordo Plenamente</th>
                    <th>Concordo</th>
                    <th>Discordo</th>
                    <th>Discordo Plenamente</th>
                    <th>N/A</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($descricoes as $row) { ?>

                    <tr>
                        <td>
                            <?php echo $row['avaliacao'] == 1 ? '😄' : 
                            ($row['avaliacao'] == 2 ? '😊' : 
                            ($row['avaliacao'] == 3 ? '😢' : 
                            ($row['avaliacao'] == 4 ? '😞' : 
                            ($row['avaliacao'] == 5 ? '😐' : '')))); ?>
                        </td>
                        <td><?php echo $row['Descricao']; ?></td>
                        <td><?php echo $row['avaliacao'] == 1 ? '✔' : ''; ?></td>
                        <td><?php echo $row['avaliacao'] == 2 ? '✔' : ''; ?></td>
                        <td><?php echo $row['avaliacao'] == 3 ? '✔' : ''; ?></td>
                        <td><?php echo $row['avaliacao'] == 4 ? '✔' : ''; ?></td>
                        <td><?php echo $row['avaliacao'] == 5 ? '✔' : ''; ?></td>





                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </form>
</div>



<?php require_once('./inc/footer.inc.php'); ?>