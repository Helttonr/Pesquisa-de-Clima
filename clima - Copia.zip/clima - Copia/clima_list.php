<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();

require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');

// Consulta SQL para buscar os dados
$sql = "SELECT dc.*, tc.Nome AS NomeTipoClima, dc.ID as ID_descricao_clima
        FROM descricao_clima dc
        INNER JOIN tipo_clima tc ON dc.tipo_clima_ID = tc.ID";

$stmt = $PDO->prepare($sql);
$stmt->execute();
$tipo_clima = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">
    <h5 class="panel-title"><img src="./img/dashboard/clima.png" width="100" height="70" alt="">Dados do Formulário</h5>  
    <hr>
    <form class="form-horizontal" method="POST" action="clima_list_save.php" onsubmit="return validateForm()">
        <!-- Oculto Levar o ID do tipo de clima -->
        <input type="hidden" name="ID_tipoclima" id="ID_tipoclima" value="<?= $idretorna ?>">
        <div class="row">
          <div class="col-sm-12 form-group">
            <label class="form-label"><b>Unidade:</b></label>
            <input type="text" class="form-control" id="Unidade" name="Unidade" placeholder="Digite Unidade" required>
          </div>

          <div class="col-sm-12 form-group">
            <label class="form-label"><b>Qual seu departamento:</b></label>
            <input type="text" class="form-control" id="NomeDepartamento" name="NomeDepartamento" placeholder="Digite seu departamento" required>
          </div>

          <div class="col-sm-12 form-group">
            <label class="form-label"><b>Trabalho na Sesé há quanto tempo:</b></label>
            <input type="text" class="form-control" id="TempoSese" name="TempoSese" placeholder="Digite há quanto tempo" required>
          </div>



          <div class="col-sm-12 form-group">
            <label class="form-label"><b>Informe o nome do gestor responsável por sua operação:</b></label>
            <input type="text" class="form-control" id="ResponsavelOperacao" name="ResponsavelOperacao" placeholder="Digite responsável por sua operação" required>
          </div>
          <div class="col-sm-12 form-group">
            <label class="form-label"><b>Qual o nome do seu gestor direto:</b></label>
            <input type="text" class="form-control" id="GestorDireto" name="GestorDireto" placeholder="Digite seu gestor direto" required>
          </div>
       
        <?php 
        $tipo_clima_id_anterior = null; // Variável para armazenar o tipo_clima_ID anterior
        
        foreach ($tipo_clima as $index => $row) { 
            // Verifica se o tipo_clima_ID é diferente do anterior para exibir o nome do tipo de clima
            if ($row['tipo_clima_ID'] != $tipo_clima_id_anterior) {
        ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover rounded">
                    <thead>
                        <tr>
                            <th><?php echo $row['NomeTipoClima']; ?></th>
                            <th>Escolha</th>
                            <th>#</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php } // Fim da verificação do tipo_clima_ID ?>

                        <tr>
                            <td><?php echo $row['Descricao']; ?></td>
                            <td>
                                <input type="radio" name="option[<?= $index ?>]" value="1" onclick="showIcon(this, <?= $index ?>)" required /> Concordo Plenamente<br>
                                <input type="radio" name="option[<?= $index ?>]" value="2" onclick="showIcon(this, <?= $index ?>)" required /> Concordo<br>
                                <input type="radio" name="option[<?= $index ?>]" value="3" onclick="showIcon(this, <?= $index ?>)" required /> Discordo<br>
                                <input type="radio" name="option[<?= $index ?>]" value="4" onclick="showIcon(this, <?= $index ?>)" required /> Discordo Plenamente<br>
                                <input type="radio" name="option[<?= $index ?>]" value="5" onclick="showIcon(this, <?= $index ?>)" required /> N/A<br>
                            </td>
                            <td align="center">
                                <i id="icon-<?= $index ?>" class="fa" aria-hidden="true"></i>
                            </td>
                        </tr>
                        
                    <?php 
                    // Atualiza o tipo_clima_ID anterior para a próxima iteração
                    $tipo_clima_id_anterior = $row['tipo_clima_ID']; 
                    } // Fim do loop foreach ?>
                    
                    </tbody>
                </table>
            </div>
        
        <div class="table-responsive">
            <table class="table table-bordered table-hover rounded">
                <thead>
                    <tr>
                        <th>Caso queira, nos deixe seu comentário</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" class="form-control" id="Obs" name="Obs" placeholder="Caso queira, nos deixe seu comentário"></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="footer d-flex justify-content-between mb-3">
            <button type="submit" data-toggle="tooltip" data-placement="top" title="Salvar" class="btn btn-primary me-2" name="action" id="action" value="insert"><i class="fa-sharp fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar</button>
             </div>
    </form>
</div>

<script>
    function showIcon(radio, index) {
        var icon = document.getElementById('icon-' + index);
        var svgSmile1 = "😄";
        var svgSmile2 = "😃";        
        var svgSad = "😡";
        var svgAngry = "🤬";
        var svgNone = "😐";

        if (radio.value == '1') {
            icon.innerHTML = svgSmile1;
        } else if (radio.value == '2') {
            icon.innerHTML = svgSmile2;
        } else if (radio.value == '3') {
            icon.innerHTML = svgSad;
        } else if (radio.value == '4') {
            icon.innerHTML = svgAngry;
        } else if (radio.value == '5') {
            icon.innerHTML = svgNone;
        }
    }

    function validateForm() {
        // Validar campos de texto
        var textInputs = document.querySelectorAll('input[type="text"]');
        for (var i = 0; i < textInputs.length; i++) {
            if (textInputs[i].value.trim() === '') {
                alert('Por favor, preencha todos os campos de texto.');
                return false; // Impede o envio do formulário se algum campo estiver vazio
            }
        }

        // Validar radios
        var radios = document.querySelectorAll('input[type="radio"]:checked');
        if (radios.length < <?= count($tipo_clima) ?>) {
            alert('Por favor, selecione uma opção em cada linha de avaliação.');
            return false; // Impede o envio do formulário se algum grupo de radio não estiver selecionado
        }

        return true; // Permite o envio do formulário se todas as validações passarem
    }
</script>

<?php require_once('./inc/footer.inc.php'); ?>
