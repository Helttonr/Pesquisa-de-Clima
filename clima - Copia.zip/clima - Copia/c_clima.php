<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();

require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');

$sql = "SELECT *  FROM tipo_clima WHERE Ativo = 'SIM'";
$stmt = $PDO->prepare($sql);
$stmt->execute();
$tipo_clima = $stmt->fetchAll(PDO::FETCH_ASSOC);



?>

<div class="container-fluid">
    <h3 class="panel-title"><i class="fa fa-plus" aria-hidden="true"></i> Especificações Organizacionais</h3>
    <hr>
    <!-- MSG de Alert -->
    <?php include('message/message.php'); ?>



    <form name="form1" class="row g-3" method="post" action="c_clima_save.php">

        <div class="col-sm-5 form-group">
            <label class="form-label"><b>Grupo:</b></label>
            <select class="form-control" name="tipo_clima_ID" id="tipo_clima_ID">
                <option>Selecione</option>
                <?php foreach ($tipo_clima as $row) {
                    echo "<option value='{$row['ID']}'>{$row['Nome']}</option>";
                } ?>
            </select>
        </div>
        <div class="col-sm-7 form-group">
            <label class="form-label"><b>Descrição:</b></label>
            <input type="text" class="form-control" id="Descricao" name="Descricao" placeholder="Digite a descrição do clima organizacional">
        </div>
        <div class="col-md-12">
            <!-- Botão de Gravar -->
            <div class="footer d-flex justify-content-between mb-3">
                <button type="submit" class="btn btn-primary me-2" name="action" id="action" value="insert"><i class="fa-sharp fa-solid fa-floppy-disk" aria-hidden="true"></i> Salvar</button>
                <a id="Pesquisa" href="clima_pes.php" class="btn btn-secondary text-white"><span class="fa fa-search"></span> Pesquisar</a>
            </div>
        </div>
</div>
</form>
</div>

<?php require_once('./inc/footer.inc.php'); ?>