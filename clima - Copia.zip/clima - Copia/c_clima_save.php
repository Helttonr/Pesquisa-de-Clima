<?php
require_once('Connections/connection.php');


session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();

// Verifica se o formulário foi submetido via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Captura dos dados do formulário
    $Descricao = isset($_POST["Descricao"]) ? $_POST["Descricao"] : null;
    $tipo_clima_ID = isset($_POST["tipo_clima_ID"]) ? $_POST["tipo_clima_ID"] : null; // Ajuste no nome do campo

    $action = isset($_POST["action"]) ? $_POST["action"] : null;

    if ($action == "insert") {
        // Verifica se ambos os campos foram preenchidos
        if (empty($Descricao) || empty($tipo_clima_ID)) {
            $_SESSION['erro'] = "Por favor, selecione um grupo e preencha a descrição.";
            header("Location: c_clima.php");
            exit;
        }

        // Preparação da consulta SQL para inserção
        $sql = "INSERT INTO descricao_clima (Descricao, tipo_clima_ID) VALUES (:Descricao, :tipo_clima_ID)";

        $stmt = $PDO->prepare($sql);
        $stmt->bindParam(':Descricao', $Descricao);
        $stmt->bindParam(':tipo_clima_ID', $tipo_clima_ID);
        $result = $stmt->execute();
        if ($result) {
            $_SESSION['salvo'] = "Salvo com sucesso!";
            header("Location: c_clima.php");
            exit;
        } else {
            $_SESSION['salvo'] = "Erro: Não foi possível salvar!";
            header("Location: c_clima.php");
            exit;
        }
   
} else {
    // Se não foi POST, redireciona para a página correta
    header("Location: c_clima.php");
    exit;
}
}