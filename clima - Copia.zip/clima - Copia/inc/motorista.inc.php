<nav class="navbar  navbar-expand-lg fixed-top navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="principal.php"><img src="./img/logo.png" width="100" height="25" alt=""></a>
    <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse2">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle " href="#" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Cadastro</a>
          <div class="dropdown-menu" aria-labelledby="dropdown01">
            <a class="dropdown-item" href="c_usuario-altera-senha.php">Trocar Senha</a>
            <a class="dropdown-item" onClick="location.href ='index.php'">Sair</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Relatórios</a>
          <div class="dropdown-menu" aria-labelledby="dropdown01">
            <a class="dropdown-item" href="check_list.php">CheckList</a>
        
            <a class="dropdown-item" onClick="location.href ='index.php'">Sair</a>

      </ul>





</nav>