<nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="principal.php"><img src="./img/logoazul.png" width="50" height="45" alt=""></a>
    <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse2">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse2">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Cadastro</a>
          <div class="dropdown-menu" aria-labelledby="dropdown01">
          <a class="dropdown-item" href="c_clima.php">Especificações do Clima </a>         
            <a class="dropdown-item" href="c_usuario.php">Usuario</a>           
            <a class="dropdown-item" onClick="location.href ='index.php'">Sair</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="dropdown02" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Relatórios</a>
          <div class="dropdown-menu" aria-labelledby="dropdown02">
          <a class="dropdown-item" href="clima_pes.php">Pesquisa Clima </a>  
          <a class="dropdown-item" href="c_clima_form.php">Pesquisa Formulários </a>          
            <a class="dropdown-item" onClick="location.href ='index.php'">Sair</a>
          </div>
        </li>

      </ul>
    </div>
  </div>
</nav>
