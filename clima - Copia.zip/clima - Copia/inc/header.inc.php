<!DOCTYPE html>
<html lang="pt-BR">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>SISSBR</title>
	<link rel="stylesheet" type="text/css" href="css/app.css">
	
	<link rel="icon" href="./img/assets/ico/512x512-1-32x32.png" sizes="192x192" />

	<link rel="stylesheet" type="text/css" href="vendor/fontawesome/css/fontawesome.css" />
	
	<link href="vendor/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="vendor/fontawesome/css/solid.css" />

	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/popper.min.js.map">


	<link href="vendor/DataTables-1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" />
	<link href="vendor/DataTables-1.10.16/css/buttons.dataTables.min.css" rel="stylesheet" />
	<link href="vendor/DataTables-1.10.16/css/responsive.dataTables.min.css" rel="stylesheet" />
	<link href="vendor/jquery-ui/themes/base/jquery-ui.min.css" rel="stylesheet" />

</head>

<body>