<!--  Chama MSG salvar -->
<?php
if (isset($_SESSION['salvo'])) :
?>
    <div id="salvo" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Parabéns!</strong> <?= $_SESSION['salvo']; ?>
        
    </div>
<?php
    unset($_SESSION['salvo']);
endif;
?>
<!--  Chama MSG valida -->
<?php
if (isset($_SESSION['valida'])) :
?>
    <div id="valida" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Alerta!</strong> <?= $_SESSION['valida']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php
    unset($_SESSION['valida']);
endif;
?>


<!-- Validar usuario no Index -->
<?php
if (isset($_SESSION['validacao_usuario'])) :
?>

    <body>
        <div id="validacao_usuario" class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Usúario ou senha incorreta.</strong> <?= $_SESSION['validacao_usuario']; ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>

           
        </div>
    </body>
<?php
    unset($_SESSION['validacao_usuario']);
endif;
?>


<?php
if (isset($_SESSION['edit'])) :
?>
<div id="edit" class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Parabéns!  </strong> <?= $_SESSION['edit']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php
    unset($_SESSION['edit']);
endif;
?>

<!--  Chama MSG Opre -->



<?php
if (isset($_SESSION['erro'])) :
?>
    <body>
        <div id="erro" class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Erro! </strong><?= $_SESSION['erro']; ?>
            
            
        </div>
    </body>
<?php
    unset($_SESSION['erro']);
endif;
?>



<!-- Tempo do  Mensagem -->
<script>
    setTimeout(function() {
        document.getElementById("conferencia").style.display = "none";
    }, 5000);

    function hide() {
        document.getElementById("erconferenciaro").style.display = "none";
    }
</script>



<!-- Tempo do  Mensagem -->
<script>
    setTimeout(function() {
        document.getElementById("erro").style.display = "none";
    }, 2000);

    function hide() {
        document.getElementById("erro").style.display = "none";
    }
</script>


<!-- Tempo do  Mensagem -->
<script>
    setTimeout(function() {
        document.getElementById("edit").style.display = "none";
    }, 2000);

    function hide() {
        document.getElementById("edit").style.display = "none";
    }
</script>

<!-- Tempo do  Mensagem -->
<script>
    setTimeout(function() {
        document.getElementById("salvo").style.display = "none";
    }, 3000);

    function hide() {
        document.getElementById("salvo").style.display = "none";
    }
</script>


<script>
    setTimeout(function() {
        document.getElementById("validacao_usuario").style.display = "none";
    }, 2000);

    function hide() {
        document.getElementById("validacao_usuario").style.display = "none";
    }
</script>