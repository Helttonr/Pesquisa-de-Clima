<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();

require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');


/*  Select Menu de  Cadastro de Usuario na pesquisa */
$sql = "SELECT  * FROM usuario where ativo = 'SIM'";
$stmt = $PDO->prepare($sql);
$stmt->execute();
$user = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*  Select Menu de  Cadastro de perfil */
$sql_parada = "SELECT  * FROM  c_perfil";
$stmt = $PDO->prepare($sql_parada);
$stmt->execute();
$Perfil = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*  Select Menu de  Cadastro de Unidade */
$sql_parada = "SELECT  * FROM  c_unidade";
$stmt = $PDO->prepare($sql_parada);
$stmt->execute();
$Unidade = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*  Select Menu de  Cadastro de turno */
$sql_parada = "SELECT  * FROM  c_turno";
$stmt = $PDO->prepare($sql_parada);
$stmt->execute();
$turno = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*  Select Menu de  Cadastro de turno */
$sql_parada = "SELECT  * FROM c_atividade";
$stmt = $PDO->prepare($sql_parada);
$stmt->execute();
$Atividade = $stmt->fetchAll(PDO::FETCH_ASSOC);


$sql_parada = "SELECT  * FROM c_ativo";
$stmt = $PDO->prepare($sql_parada);
$stmt->execute();
$ativo = $stmt->fetchAll(PDO::FETCH_ASSOC);




?>



<form id="form1" name="form1" class="form-horizontal" method="POST" action="c_usuario_save.php">
  <div class="col-lg-12">
    <div class="card mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-plus" aria-hidden="true"></i> Novo Usuário</h6>
      </div>
      <br>
      <!-- MSG de Alert -->
      <?php include('message/message.php'); ?>
      <div class="card-body">
        <div class="row">
          <div class="col-sm-2 form-group">
            <label class="form-label"><b>Matricula:</b></label>
            <input type="text" class="form-control" id="Matricula" name="Matricula" placeholder="Digite Matricula" required>
          </div>

          <div class="col-sm-4 form-group">
            <label class="form-label"><b>Nome Completo:</b></label>
            <input type="text" class="form-control" id="Nome" name="Nome" placeholder="Digite Seu Nome Completo" required>
          </div>

          <div class="col-sm-3 form-group">
            <label class="form-label"><b>Setor:</b></label>
            <select class="form-control" name="Setor" id="Setor" required>
              <option value="">Selecione</option>
              <?php foreach ($Atividade as $row) {
                echo "<option >$row[Nome] </option>";
              }   ?>
            </select>
          </div>

          <div class="col-sm-2 form-group">
            <label class="form-label"><b>Turno:</b></label>
            <select class="form-control" name="Turno" id="Turno" required>
              <option value="">Selecione</option>
              <?php foreach ($turno as $row) {
                echo "<option >$row[nome] </option>";
              }   ?>
            </select>
          </div>


          <div class="col-sm-4 form-group">
            <label class="form-label"><b>E-mail:</b></label>
            <input type="email" class="form-control" id="Email" name="Email" placeholder="Digite Seu E-mail">
          </div>

          <div class="col-sm-3 form-group">
            <label class="form-label"><b>Senha:</b></label>
            <input type="password" class="form-control" id="Senha" name="Senha" placeholder="Digite Sua Senha" required>
          </div>
          <div class="col-sm-2 form-group">
            <label class="form-label"><b>Perfil:</b></label>
            <select class="form-control" name="Perfil" id="Perfil" required>
              <?php
              foreach ($Perfil as $row) {
                // Mostra a opção apenas se não for "administrador"
                if ($row['Nome'] !== 'administrador') {
                  echo "<option>$row[Nome]</option>";
                }
              }
              ?>
            </select>
          </div>
    

        <div class="col-sm-2 form-group">
          <label class="form-label"><b>Unidade:</b></label>
          <select class="form-control" name="Unidade" id="Unidade" required>
            <option>Selecione</option>
            <?php foreach ($Unidade as $row) {
              echo "<option >$row[Nome] </option>";
            }   ?>
          </select>
        </div>
        </div>
        <!-- Botão de Gravar -->
        <div class="footer">
          <button type="submit" data-toggle="tooltip" data-placement="top" title="Salvar" class="btn btn-primary" name="action" id="action" value="insert">Salvar
          </button>
          <a id="voltar_pagina" href="principal.php" class=" btn btn-danger" title="Voltar ao início"><span class="fa fa-home"></span></a>
          </button>
        </div>
        <br>
        <div class="card shadow mb-8">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"></h6><i class="fa fa-chart-area" aria-hidden="true"></i>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="tabela" width="100%" cellspacing="0">
                <thead class="table">
                  <tr class="">
                    <th>Matricula</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Unidade</th>
                    <th>Perfil</th>
                    <th>Editar</th>
                  </tr>
                </thead>
                <tbody>

                  <?php foreach ($user as $row_func) { ?>
                    <tr>
                      <td><?php echo $row_func['Matricula']; ?></td>
                      <td><?php echo $row_func['Nome']; ?></td>
                      <td><?php echo $row_func['Email']; ?></td>
                      <td><?php echo $row_func['Unidade']; ?></td>
                      <td><?php echo $row_func['Perfil']; ?></td>
                      <td><a href='c_usuario_edit.php?id=<?php echo $row_func['Matricula']; ?>' class='btn btn-outline-danger' data-placement="top" title="Editar"><i class="fa fa-pencil-alt" aria-hidden="true"></i></td>

                    </tr>
                  <?PHP } ?>
                </tbody>
              </table>
</form>
<?php require_once('./inc/footer.inc.php'); ?>

