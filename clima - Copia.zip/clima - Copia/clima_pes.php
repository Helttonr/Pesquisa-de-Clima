<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

$PDO = db_connect();

require_once('./inc/header.inc.php');
require_once('./inc/' . $perfil . '.inc.php');

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo_clima_ID = isset($_POST["tipo_clima_ID"]) ? $_POST["tipo_clima_ID"] : '';
    $keyword = isset($_POST["keyword"]) ? $_POST["keyword"] : '';

    // Construir a consulta SQL com base nos filtros
    $sql = "SELECT dc.*, tc.Nome AS NomeTipoClima
            FROM descricao_clima dc
            INNER JOIN tipo_clima tc ON dc.tipo_clima_ID = tc.ID
            WHERE (:tipo_clima_ID = '' OR dc.tipo_clima_ID = :tipo_clima_ID)
              AND (dc.Descricao LIKE :keyword) and dc.Ativo = 'SIM'";
    
    $stmt = $PDO->prepare($sql);
    $stmt->bindValue(':tipo_clima_ID', $tipo_clima_ID);
    $stmt->bindValue(':keyword', "%$keyword%");
    $stmt->execute();
    $tipo_clima = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Caso o formulário não tenha sido enviado, listar todos os registros inicialmente
    $sql = "SELECT dc.*, tc.Nome AS NomeTipoClima
            FROM descricao_clima dc
            INNER JOIN tipo_clima tc ON dc.tipo_clima_ID = tc.ID Where dc.Ativo = 'SIM'";
    
    $stmt = $PDO->prepare($sql);
    $stmt->execute();
    $tipo_clima = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Consulta para obter todos os tipos de clima para o menu suspenso
$sql_tipo = "SELECT * FROM tipo_clima";
$stmt_tipo = $PDO->prepare($sql_tipo);
$stmt_tipo->execute();
$tipos = $stmt_tipo->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="container mt-2">
    <h3 class="panel-title"><i class="fa fa-search" aria-hidden="true"></i> Pesquisa Organizacionais</h3>
    <hr>
    <!-- MSG de Alert -->
    <?php include('message/message.php'); ?>


    <form name="form1" class="row g-3" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    
        <div class="col-sm-5 form-group">
            <label class="form-label"><b>Grupo:</b></label>
            <select class="form-control" name="tipo_clima_ID" id="tipo_clima_ID">
                <option value="">Selecione</option>
                <?php foreach ($tipos as $tipo) {
                    $selected = ($tipo['ID'] == $tipo_clima_ID) ? 'selected' : '';
                    echo "<option value='{$tipo['ID']}' $selected>{$tipo['Nome']}</option>";
                } ?>
            </select>
        </div>

        <div class="col-sm-7 form-group">
            <label class="form-label"><b>Pesquisa por Descrição:</b></label>
            <input type="text" class="form-control" id="keyword" name="keyword" placeholder="Digite uma palavra-chave" value="<?php echo isset($keyword) ? $keyword : ''; ?>">
        </div>

        <div class="col-md-12">
    
                <!-- Botão de Pesquisar -->
                <div class="footer d-flex justify-content-between mb-3">
                    <button type="submit" class="btn btn-primary me-2" name="action" id="action" value="search"><i class="fa-sharp fa-solid fa-search" aria-hidden="true"></i> Pesquisar</button>
                </div>
            </div>
       
    </form>

    <table class="table table-bordered table-hover rounded responsive" style="width:100%" id="tabela">
    <thead class="table">
      <tr class="">
                <th>Grupo</th>
                <th>Descrição</th>
                <th>Editar</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tipo_clima as $row) { ?>
                <tr>
                    <td><?php echo $row['NomeTipoClima']; ?></td>
                    <td><?php echo $row['Descricao']; ?></td>
                    <td><a href='clima_pes_edit.php?ID=<?php echo $row['ID']; ?>' class='btn btn-outline-danger' data-placement="top" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php require_once('./inc/footer.inc.php'); ?>
