﻿<?php 

    
//abre conexão
  ini_set('display_errors', true); 
  error_reporting(E_ALL);
$mes = date("m");
$Data = date("d-m-Y");
$Hora = date("H:i:s");
$ano = date("Y");



function db_connect()
{

	define('DB_HOSTNAME', 'localhost');
	define('DB_DATABASE', 'clima');
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', 'Matrix@720721');
	define('DB_CHARSET','utf8');
    $opcoes = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8');
    $PDO = new PDO("mysql:host=".DB_HOSTNAME."; dbname=".DB_DATABASE, DB_USERNAME, DB_PASSWORD, $opcoes);
	$PDO -> setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
  
    return $PDO;
}

 