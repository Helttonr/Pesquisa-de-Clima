<?php
require_once('Connections/connection.php');
session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];
$turno = $_SESSION['sturno'];

// Verificar se o formulário foi submetido via método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar os dados do formulário
   
    $NomeDepartamento = $_POST['NomeDepartamento'];
    $TempoSese = $_POST['TempoSese'];
    $ResponsavelOperacao = $_POST['ResponsavelOperacao'];
    $GestorDireto = $_POST['GestorDireto'];
    $option = $_POST['option']; // Array com as opções de avaliação
    $Obs = $_POST['obs'];

    // Verificar se todos os campos obrigatórios foram preenchidos
    if (empty($NomeDepartamento) || empty($TempoSese) || empty($ResponsavelOperacao) || empty($GestorDireto) || empty($option)) {
        die("Erro: Todos os campos são obrigatórios.");
    }

    try {
        // Conectar ao banco de dados
        $PDO = db_connect();



        // Preparar a query de inserção para dados_formulario
        $sql = "INSERT INTO dados_formulario ( unidade, NomeDepartamento, TempoSese, ResponsavelOperacao, GestorDireto, Obs, DataHora) 
                VALUES (:unidade, :NomeDepartamento, :TempoSese, :ResponsavelOperacao, :GestorDireto, :Obs, NOW())";
        $stmt = $PDO->prepare($sql);
        
        // Bind dos parâmetros

        $stmt->bindParam(':unidade', $unidade);
        $stmt->bindParam(':NomeDepartamento', $NomeDepartamento);
        $stmt->bindParam(':TempoSese', $TempoSese);
        $stmt->bindParam(':ResponsavelOperacao', $ResponsavelOperacao);
        $stmt->bindParam(':GestorDireto', $GestorDireto);
        $stmt->bindParam(':Obs', $Obs);
        $stmt->execute();

        // Recuperar o ID do último registro inserido
        $formulario_id = $PDO->lastInsertId();



        // Preparar a query de inserção para dados_item
        $sqlAvaliacao = "INSERT INTO dados_item (formulario_id, avaliacao) VALUES (:formulario_id, :avaliacao)";
        $stmtAvaliacao = $PDO->prepare($sqlAvaliacao);

        // Iterar sobre as opções de avaliação e inserir na tabela dados_item
        foreach ($option as $index => $avaliacao) {
            $stmtAvaliacao->bindParam(':formulario_id', $formulario_id);
            $stmtAvaliacao->bindParam(':avaliacao', $avaliacao);
           
            $stmtAvaliacao->execute();
        }

        $_SESSION['salvo'] = "";
        header("Location: c_clima_form.php");
        exit();
    } catch (PDOException $e) {
        die("Erro ao inserir no banco de dados: " . $e->getMessage());
    }
} else {
    // Se o método de requisição não for POST, redirecionar para página de erro

    $_SESSION['erro'] = "Método POST não foi enviado";
    header("Location: c_clima_form.php");
    exit();
}
?>
