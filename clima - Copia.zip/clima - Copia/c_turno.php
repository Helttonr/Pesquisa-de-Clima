<?php
require_once('Connections/connections.php'); 
$PDO = db_connect();

session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];

require_once('./inc/header.inc.php');


isset($perfil) ?  require_once('./inc/' . $perfil . '.inc.php') : header("Location: index.php");

$sql = "SELECT  * FROM c_turno ";
$stmt = $PDO->prepare($sql);
$stmt->execute();
$prepara = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

  <form id="form1" name="form1" class="form-horizontal" method="POST" action="c_turno_save.php">
    <div class="col-lg-12">
        <div class="card mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fa fa-plus" aria-hidden="true"></i>  Turno
                </h6>
            </div>
            <!-- MSG de Alert -->
            <?php include('message/message.php'); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12 form-group">
                        <label class="form-label"><b>Nome:</b></label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="Nome" name="Nome" placeholder="Digite Nome" required>
                            <div class="input-group-append">
                                &nbsp; <button type="submit" data-toggle="tooltip" data-placement="top" title="Salvar" class="btn btn-primary" name="action" id="action" value="insert">Salvar</button>
                            </div>
                            &nbsp;<div class="input-group-append">
                                <a id="voltar_pagina" href="principal.php" class="btn btn-danger" title="Voltar ao início"><span class="fa fa-home"></span></a>
                            </div>
                        </div>
                    </div>
                </div>

                <hr>



    <hr>

<table class="table table-bordered table-hover rounded responsive" style="width:100%" id="tabela_fornecedor">
  <thead class="table">
    <tr class="">
      <th>Codigo</th>
      <th>Nome</th>
       
        <th>Editar</th>
       
     
    </tr>
  </thead>
  <?php
  foreach ($prepara as $row) {
    echo "<tr>";
    echo "<td>" . $row['codigo'] . "</td>";
    echo "<td>" . $row['nome'] . "</td>";   
    echo "<td> <a href='c_turno_edit.php?codigo=$row[codigo]'><center><i class='fa fa-pencil-alt text-danger'></i> </center></a> </td>";
    echo "</tr>";
  }
  ?>
</table>

<?php require_once('./inc/footer.inc.php'); ?>