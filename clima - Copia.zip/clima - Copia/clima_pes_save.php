<?php
try{


require_once('Connections/connection.php');
$PDO = db_connect();

session_start();
$matricula = $_SESSION['smatricula'];
$perfil = $_SESSION['sperfil'];
$nome = $_SESSION['snome'];
$unidade = $_SESSION['sunidade'];


  // Enviar os dados da tela para Banco de dados
  $ID = isset($_POST["ID"]) ? $_POST["ID"] : null;
  $Descricao = isset($_POST["Descricao"]) ? $_POST["Descricao"] : null;
  $Ativo = isset($_POST["Ativo"]) ? $_POST["Ativo"] : null;

  $action = isset($_POST["action"]) ? $_POST["action"] : null;

if ($action == "update") {

    $sql_entrada = "UPDATE descricao_clima SET Descricao=:Descricao,Ativo=:Ativo WHERE ID=:ID";
    $stmt_entrada = $PDO->prepare($sql_entrada);
    $stmt_entrada->bindParam(':ID', $ID);
    $stmt_entrada->bindParam(':Descricao', $Descricao);
    $stmt_entrada->bindParam(':Ativo', $Ativo);
    $result = $stmt_entrada->execute();   
    if ($result) {
      $_SESSION['editado'] = "Editado  Com Sucesso!";
      header("Location: clima_pes.php");
      exit(0);
    } else {
      $_SESSION['editado'] = "Erro  Não foi possivel Edição!";
      header("Location: clima_pes.php");
      exit(0);
    }
  }
  
} catch (PDOException $e) {


  echo 'Error: ' . $e->getMessage();
}
